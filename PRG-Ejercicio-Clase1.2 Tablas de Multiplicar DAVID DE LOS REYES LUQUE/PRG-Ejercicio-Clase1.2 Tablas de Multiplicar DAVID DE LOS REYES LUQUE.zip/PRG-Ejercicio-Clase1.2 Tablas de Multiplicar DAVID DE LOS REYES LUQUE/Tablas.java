public class Tablas {

		public static void main(String[] args) {
			
			int x = 0;
	        int y = 0;
	        
	        while (y <= 10) {
	        	
	            System.out.println (x+ "x" +y+ "=" +x * +y);
	            y = y+1;
	            
	        }
	        
	        x = 1;
	        y = 0;
	        
	        while (y <= 10) {
	        	
	            System.out.println (x+ "x" +y+ "=" +x * +y);
	            y = y+1;
	            
	        }
	        
	        x = 2;
	        y = 0;
	        
	        while (y <= 10) {
	        	
	            System.out.println (x+ "x" +y+ "=" +x * +y);
	            y = y+1;
	            
	        }
	        
	        x = 3;
	        y = 0;
	        
	        while (y <= 10) {
	        	
	            System.out.println (x+ "x" +y+ "=" +x * +y);
	            y = y+1;
	            
	        }
	        
	        x = 4;
	        y = 0;
	        
	        while (y <= 10) {
	        	
	            System.out.println (x+ "x" +y+ "=" +x * +y);
	            y = y+1;
	            
	        }
	        
	        x = 5;
	        y = 0;
	        
	        while (y <= 10) {
	        	
	            System.out.println (x+ "x" +y+ "=" +x * +y);
	            y = y+1;
	            
	        }
	        
	        x = 6;
	        y = 0;
	        
	        while (y <= 10) {
	        	
	            System.out.println (x+ "x" +y+ "=" +x * +y);
	            y = y+1;
	            
	        }
	        
	        x = 7;
	        y = 0;
	        
	        while (y <= 10) {
	        	
	            System.out.println (x+ "x" +y+ "=" +x * +y);
	            y = y+1;
	            
	        }
	        
	        x = 8;
	        y = 0;
	        
	        while (y <= 10) {
	        	
	            System.out.println (x+ "x" +y+ "=" +x * +y);
	            y = y+1;
	            
	        }
	        
	        x = 9;
	        y = 0;
	        
	        while (y <= 10) {
	        	
	            System.out.println (x+ "x" +y+ "=" +x * +y);
	            y = y+1;
	            
	        }
	        
	        x = 10;
	        y = 0;
	        
	        while (y <= 10) {
	        	
	            System.out.println (x+ "x" +y+ "=" +x * +y);
	            y = y+1;
	            
	        }
		}


}
