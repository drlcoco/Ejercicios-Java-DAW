public class TablasFor {

	public static void main(String[] args) {
		
		for (int y=0; y<=10; y++) {
			int x=0;
			System.out.println(x+ "x" +y+ "=" +x * +y);
		}
		
		for (int y=0; y<=10; y++) {
			int x=1;
			System.out.println(x+ "x" +y+ "=" +x * +y);
		}
		
		for (int y=0; y<=10; y++) {
			int x=2;
			System.out.println(x+ "x" +y+ "=" +x * +y);
		}
		
		for (int y=0; y<=10; y++) {
			int x=3;
			System.out.println(x+ "x" +y+ "=" +x * +y);
		}
		
		for (int y=0; y<=10; y++) {
			int x=4;
			System.out.println(x+ "x" +y+ "=" +x * +y);
		}
		
		for (int y=0; y<=10; y++) {
			int x=5;
			System.out.println(x+ "x" +y+ "=" +x * +y);
		}
		
		for (int y=0; y<=10; y++) {
			int x=6;
			System.out.println(x+ "x" +y+ "=" +x * +y);
		}
		
		for (int y=0; y<=10; y++) {
			int x=7;
			System.out.println(x+ "x" +y+ "=" +x * +y);
		}
		
		for (int y=0; y<=10; y++) {
			int x=8;
			System.out.println(x+ "x" +y+ "=" +x * +y);
		}
		
		for (int y=0; y<=10; y++) {
			int x=9;
			System.out.println(x+ "x" +y+ "=" +x * +y);
		}
		
		for (int y=0; y<=10; y++) {
			int x=10;
			System.out.println(x+ "x" +y+ "=" +x * +y);
		}

	}

}
