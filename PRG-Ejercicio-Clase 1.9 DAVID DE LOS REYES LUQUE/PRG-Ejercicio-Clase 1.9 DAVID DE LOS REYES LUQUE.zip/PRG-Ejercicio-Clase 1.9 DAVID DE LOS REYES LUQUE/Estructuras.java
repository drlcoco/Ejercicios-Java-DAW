
public class Estructuras {

	public static void main(String[] args) {
		int suma;
		int i ;
		int j ;
		
		for (i = 1; i < 4; ++i) {
			for (j = 3; j > 0; --j) {
				suma = i * 10 + j;
				System.out.println(suma);
				
			}
			
		}

	}

}
