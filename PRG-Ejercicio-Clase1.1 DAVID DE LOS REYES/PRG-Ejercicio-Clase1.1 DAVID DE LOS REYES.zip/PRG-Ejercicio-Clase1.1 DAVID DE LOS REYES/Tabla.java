public class Tabla {
	public static void main(String[] args) {
		int x=3;
		int y=0;
		
		 while (y < 10); {
	    	 System.out.print( x+ "x" +y+ "=" +x * y);
		     y++;
		  }
	}
}